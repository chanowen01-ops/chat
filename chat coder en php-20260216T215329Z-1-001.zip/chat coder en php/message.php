<?php
    if (isset($_SESSION["user"])) {
        //si l'utilisateur est connecter 
        //connection à la base de donées 
        include "connetion_bdd.php";
        $req= mysqli_query($con, "SELECT* FROM message ORDER BY id_m DESC");
        if(mysqli_num_rows($req )== 0){
             //si la messagerie est vide
             echo "your messagerie is empty";
        }else{
            //si oui
            while ($row = mysqli_fetch_assoc($req)) {
                //si c'est vous qui avez envoyer le message on utilise ce format
            if ($row['mail']== $_SESSION["user"]) {
                ?>
                <div class="message your_message">
                <span>you</span>
                <p><?=$row["msg"]?></p>
                <p class="date"><?=$row["date"]?></p>
            </div>
                <?php 
            }else{
                //si vous n'etes pas l'auteur de ce message on l'ajoute sous ce format
                ?>
                <div class="message other_message">
                <span><?=$row["mail"]?></span>
                <p><?=$row["msg"]?></p>
                <p class="date"><?=$row["date"]?></p>
            </div>
                <?php
            }
            }
        }
    }
?>