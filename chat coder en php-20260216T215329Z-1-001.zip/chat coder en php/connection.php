<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connetion to Chat</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
if (isset($_POST["button_con"])) {
    // Importer la connexion à la base de données
    include "connetion_bdd.php";

    // Extraire les données du formulaire
    $mail = trim($_POST["mail"] ?? '');
    $mdp1 = trim($_POST["mdp1"] ?? '');

    // Vérifier si les champs sont remplis
    if (!empty($mail) && !empty($mdp1)) {
        // Sécuriser les entrées utilisateur
        $mail = mysqli_real_escape_string($con, $mail);
        $mdp1 = mysqli_real_escape_string($con, $mdp1);

        // Vérifier les identifiants dans la base de données
        $req = mysqli_query($con, "SELECT * FROM user WHERE mail='$mail' AND mdp='$mdp1'");
        if (mysqli_num_rows($req) > 0) {
            // Identifiants corrects, créer la session
            $_SESSION["user"] = $mail;

            // Redirection vers la page chat
            header("location:chat.php");
            exit;
        } else {
            $error = "mail or password are incorrect.";
        }
    } else {
        $error = "st all fields.";
    }
}
?>
<form action="" class="form_connetion_inscription" method="post">
    <h1>Connetion</h1>

    <!-- Message de confirmation ou d'erreur -->
    <p class="mess">
        <?php
        if (isset($_SESSION["message"])) {
            echo $_SESSION["message"];
            unset($_SESSION["message"]); // Supprimer le message après affichage
        }
        ?>
    </p>
    <p class="error_message">
        <?php if (isset($error)) echo htmlspecialchars($error); ?>
    </p>

    <!-- Formulaire -->
    <label for="mail">mail</label>
    <input type="email" name="mail" id="mail" required>
    
    <label for="password">password</label>
    <input type="password" name="mdp1" id="password" required>
    
    <input type="submit" class="submit" value="Connexion" name="button_con">
    <p class="link">no account ? <a href="inscription.php">Create an account</a></p>
</form>
</body>
</html>