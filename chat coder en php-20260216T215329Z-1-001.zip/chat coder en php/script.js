var mpd1 = document.getElementById('mdp1');
var mpd2 = document.getElementById('mdp2');
const error_message = document.getElementById('error_message');
mpd2.addEventListener('keyup', function(){
    if(mpd1.value != mpd2.value){
        error_message.textContent= "passwords doesn't match";

    }else{
        /*sinon*/
        /*on ecrit rien dans error_message*/
        error_message.textContent= "";
    }});

