<?php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>INSCRIPTION TO CHAT</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php
if (isset($_POST["button_inscription"])) {
   //si formulaire est sent
    //on importe la base de donne
     include "connetion_bdd.php";
     //extraire les infos du formulaire
    extract($_POST);
    //verifion si les champs sont vides
    if (isset($mail) && isset($mdp1)  && $mail != "" && $mdp1 != "" && isset($mdp2) && $mdp2 != "" ){
    //verifions si les mdp correspondent
    if($mdp1 != $mdp2){
         $error="passwords don't match";
    }else{
        //sinon verifions si l'addre e-mail existe
        $req = mysqli_query ($con , "SELECT * FROM user WHERE mail='$mail'" );
        if(mysqli_num_rows($req)==0){
               //si ça n'existe pas
               $req=mysqli_query($con,"INSERT INTO user VALUES(NULL,'$mail','$mdp1')");
               if($req){
                //si le compte a ete creer,creons une variable pour afficher le message dans la page de connection
                $mess="your account were created succesfully ";
                $_SESSION["message"]="$mess";
                //rediriger ver la page de chat
                header("location:connection.php");
               }else{
                // si non 
                $error="failed inscription";
               }
        }else{
            //si ça existe 
            $error="this mail already exist";
        }
    }
     }else{
        $error="set all fields !";
        }
    }

?>

<form action="" method="post" class="form_connetion_inscription">
    <h1>INSCRIPTION</h1>
    </p>
    <p class="error_message" id="error_message" >
        <?php
         if (isset($error)) {
            echo $error;
         }
    ?></p>
    <label for="mail" class="mail">Adresse email</label>
    <input type="mail" name="mail" class="mail">
    <label for="password" class="password">password</label>
    <input type="password"  id="mdp1" name="mdp1">
    <label for="password" class="password">confirm password</label>
    <input type="password"  id="mdp2" name="mdp2">
    <input type="submit" class="submit" name=" button_inscription" value="inscription">
    <p class="link">do you have an account ? <a class="no" href="connection.php">log in</a></p>

</form>
<script src="script.js"></script>
</body>
</html>