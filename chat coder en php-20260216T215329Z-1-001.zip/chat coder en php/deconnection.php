<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION["user"])) {
    // Redirection vers la page de connexion si non connecté
    header("location:connection.php");
    exit;
}

// destuction de toutes les sessions
session_destroy();
//redirection vers la pge de connection
header("location:connection.php");
?>