<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION["user"])) {
    // Redirection vers la page de connexion si non connecté
    header("location:connection.php");
    exit;
}

// Récupérer l'email de l'utilisateur depuis la session
$user = $_SESSION["user"];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>welco to Chat</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="chat">
        <!-- Afficher l'email de l'utilisateur -->
        <div class="email_button">
            <span><?= htmlspecialchars($user) ?></span>
        </div>
        <a href="deconnection.php" class="deconnection_btn">Deconnetion</a>
        <div class="message_box">
        <?php
        //inclure la page message.php
        include "message.php";
        ?> 
        </div>
        <?php
// Gestion de l'envoi d'un nouveau message
if (isset($_POST['sent'])) {
    $message = trim($_POST['message']);
    if (!empty($message)) {
        // Connexion à la base de données
        include "connetion_bdd.php";

        // Sécurisation des données
        $message = mysqli_real_escape_string($con, $message);
        $user = mysqli_real_escape_string($con, $user);

        // Insertion du message dans la base de données
        $query = "INSERT INTO message (id_m, mail, msg, date) VALUES (NULL, '$user', '$message', NOW())";
        mysqli_query($con, $query);
        
        // Recharge la page pour afficher le nouveau message
        header("location:chat.php");
        exit;
    }
}
?>
        <!-- Formulaire pour envoyer un message -->
        <form  class="sent_message" method="post">
            <textarea name="message" cols="30" rows="2" id="message" placeholder="typr your message here..."></textarea>
            <input type="submit" value="send" class="envoyer" name="sent">
        </form>
    </div>
    <script>
    // Recharger la page toutes les 500ms
    setInterval(function() {
        window.location.reload();  // Recharger la page
    }, 5000);  // Actualisation toutes les 500ms
</script>
</body>
</html>
